import boto3
import csv
import pymysql
#import time


def lambda_handler(event, context):
    
    for record in event['Records']:
    
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        file_key = event['Records'][0]['s3']['object']['key']
        
        if "_temporary" in file_key:
            print(f"Skipping temporary file: {file_key}")
            continue
        print("primer for")
        process_csv(bucket_name, file_key)
        
    
def process_csv(bucket_name, file_key):
    s3 = boto3.client('s3')
    rds_host = 'XXXXXXXXXXXXXX'
    db_username = 'admin'
    db_password = 'XXX'
    db_name = 'db_name_mauro'    
    
    conn = pymysql.connect(host=rds_host,
                             user=db_username,
                             password=db_password,
                             database=db_name,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor,
                             connect_timeout=80)
    cursor = conn.cursor()
    
    print("CONNECTION CMPLETE >:P in::::", db_name)
    #time.sleep(40)
    
    print(bucket_name, "<--- este es el nombre del bcuket")
    print(file_key, "<--- este es el nombre del file_key")
    
    response = s3.get_object(Bucket=bucket_name, Key=file_key)
    data = response['Body'].read().decode('utf-8').split('\n')
    data = data[:-1] ## El ultimo está vacío por eso lo btoamos
    
    print(response)
    print(data)
    
    csv_reader = csv.reader(data)
    next(csv_reader)
    
    print("Primer print")
    
    for row in csv_reader:
        # Insert row into RDS   TIENES QUE AGARRAR EL ORDEN DEL CSV PARA METERLO AL SQL
        cursor.execute("INSERT INTO Iris_dataset1 (Id, sepal_length, sepal_width, petal_length, petal_width, Volumen_Iris, class) VALUES (%s,%s,%s,%s,%s,%s,%s)", row)
        conn.commit()
    print("Segundo print")
    cursor.close()
    print("Tercer print")
    conn.close()
    print("FINAL print")
